<?php

class RecuperarController extends \HXPHP\System\Controller
{
  
}

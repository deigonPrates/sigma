<?php 

class HaveFunController extends \HXPHP\System\Controller
{
}